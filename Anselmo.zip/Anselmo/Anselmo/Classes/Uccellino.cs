﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace Anselmo.Classes
{
    
    public class Uccellino
    {

        public long id { get; }
        public int number { get; }

        public Uccellino(long identifier, int n)
        {
            this.id = identifier;
            this.number = n;
        }

    }
}
